<?php  
/**
 * Support for Bingo for WordPress
 *
 *
 *
 * @package   Bingo
 * @author    Probal dhar <probalcse08@gmail.com>
 * @link      https://probaldhar.github.io
 * @copyright 2014 http://uouapps.com
 *
 * @wordpress-plugin
 * Plugin Name:       Bingo Support
 * Plugin URI:        http://uouapps.com/
 * Description:       Shortcode and cuztom
 * Version:           1.0.0
 * Author:            http://uouapps.com
 * Author URI:        http://uouapps.com
 */


require( 'shortcodes.php' );
require_once('cuztom/cuztom.php');

?>