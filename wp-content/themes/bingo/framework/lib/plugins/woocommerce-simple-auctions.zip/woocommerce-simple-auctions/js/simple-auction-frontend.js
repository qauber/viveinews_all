jQuery(document).ready(function($){
	running = false;
	var window_focus = true;
	if(data.interval){
   		$(window).focus(function() {
        window_focus = true;
    	});
	
    	$(window).blur(function() {
        window_focus = false;
    	});
	   refreshIntervalId =  setInterval(function(){
	        if(window_focus == true){
	           getPriceAuction();
	        }
    	}, data.interval*1000);
		//refreshIntervalId  = setInterval(getPriceAuction, data.interval*1000);   	
	}
	$( ".auction-time-countdown" ).each(function( index ) {
		var time 	= $(this).data('time');
		var format 	= $(this).data('format');
		
		if(format == ''){
			format = 'yowdHMS';
		}
		var etext ='';
		if($(this).hasClass('future') ){
			var etext = '<div class="started">'+data.started+'</div>';	
		} else{
			var etext = '<div class="over">'+data.finished+'</div>';
			
		}
		
		
		
		
		
		$(this).SAcountdown({
			until:   $.SAcountdown.UTCDate(-(new Date().getTimezoneOffset()),new Date(time*1000)),
			format: format, 
			
			onExpiry: closeAuction,
			expiryText: etext
		});
			 
	});
	
	$('form.cart').submit(function() { 
		clearInterval(refreshIntervalId);
		
	});
	
});

function closeAuction(){
		var auctionid = jQuery(this).data('auctionid');
		var ajaxcontainer = jQuery(this).parent().next('.auction-ajax-change');
		
		ajaxcontainer.empty().prepend('<div class="ajax-working"></div>');
		ajaxcontainer.parent().children('form.buy-now').remove();
		
		request =  jQuery.ajax({
         type : "post",
         url : SA_Ajax.ajaxurl,
         data : {action: "finish_auction", post_id : auctionid, ret: ajaxcontainer.length},
         success: function(response) {
         			if (response != 0){
         				ajaxcontainer.children('.ajax-working').remove();
         				ajaxcontainer.prepend(response);
         			}
                     
        	}
      	});
		
}



function getPriceAuction(){ 
    if(jQuery('.auction-price').length<1){ 
        return;
        }
    if (running == true){
    	return;
    }    
    var auction_ids={};
    jQuery(".auction-price").each(function(){
    		
        	var auction_id = jQuery(this).data('auction-id');
        	var auction_bid = jQuery(this).data('bid');
        	var auction_status= jQuery(this).data('status'); 	
    		auction_ids [auction_id]= {'price': auction_bid , 'status': auction_status};
        
    });
    if(jQuery.isEmptyObject(auction_ids)){
    	return;
    }
    running = true;
    jQuery.ajax({
     type : "post",
     encoding:"UTF-8",
     url : SA_Ajax.ajaxurl,
     data : {action: "get_price_for_auctions", "data" : auction_ids},
     success: function(response) { 
     	jQuery.each( response, function( key, value ) {
     		auction = jQuery("body").find("[data-auction-id='" + key + "']");
		    auction.html(value).addClass('changed blink').fadeIn(100).fadeOut(100).fadeIn(100).fadeOut(100).fadeIn(100).fadeOut(100).fadeIn(100).fadeOut(100).fadeIn(100, function(){jQuery(this).removeClass('blink');});
		});
     	running = false;
     	//console.log(response);
     	
    	}
    });	
		
}
jQuery(function($){$("div.quantity:not(.buttons_added), td.quantity:not(.buttons_added)").addClass("buttons_added").append('<input type="button" value="+" class="plus" />').prepend('<input type="button" value="-" class="minus" />'),$(document).on("click",".plus, .minus",function(){var t=$(this).closest(".quantity").find(".qty"),a=parseFloat(t.val()),n=parseFloat(t.attr("max")),s=parseFloat(t.attr("min")),e=t.attr("step");a&&""!==a&&"NaN"!==a||(a=0),(""===n||"NaN"===n)&&(n=""),(""===s||"NaN"===s)&&(s=0),("any"===e||""===e||void 0===e||"NaN"===parseFloat(e))&&(e=1),$(this).is(".plus")?t.val(n&&(n==a||a>n)?n:a+parseFloat(e)):s&&(s==a||s>a)?t.val(s):a>0&&t.val(a-parseFloat(e)),t.trigger("change")})});